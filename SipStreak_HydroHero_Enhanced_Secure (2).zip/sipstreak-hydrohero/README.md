# SipStreak — HydroHero Hunt (Enhanced)

A hydration dashboard with personal goals, squad leaderboard, 7-day chart, virtual plant, quick logging, reminders, and local-first persistence.

## Enhanced features
- **Daily rollover:** intake and logs reset automatically when a new local calendar day starts.
- **Undo:** remove the most recent sip entry and subtract its amount.
- **CSV export:** download today's entries for personal tracking.
- **Input guardrails:** custom logging rejects invalid or excessive amounts (1–3000 ml per entry).
- **Safer API baseline:** Helmet security headers, strict JSON/body size, origin allow-list CORS, rate limiting, no-store responses, validation, bounded in-memory log storage, generic error responses, and no Express fingerprint header.
- **Health endpoint:** `GET /api/health`.

## Requirements
Node.js 18+ recommended.

## Run locally
```bash
npm install
npm run dev
```
Frontend opens at the Vite URL (normally http://localhost:5173).

To run the API in a second terminal:
```bash
npm run server
```
API defaults to http://localhost:4000.

## CORS configuration
Allowed origins default to local Vite addresses. For deployment, set `CORS_ORIGINS` to a comma-separated list of your exact trusted origins, e.g.:
```bash
CORS_ORIGINS=https://your-domain.example npm run server
```
Do not use wildcard origins for a production deployment.

## API
- `GET /api/health`
- `GET /api/teams`
- `GET /api/leaderboard`
- `GET /api/logs?limit=100` (maximum 100 returned)
- `POST /api/logs` with JSON `{ "user": "HydroHero", "team": "Hostel Block B", "ml": 250 }`

## Security / deployment note
This is a student/demo project, not a production-secure service. Logs and team data are stored in memory and reset on server restart. The browser dashboard stores personal data in localStorage. Before public deployment, add real user authentication, authorization, persistent database storage, TLS/HTTPS, secrets management, monitoring, and automated security tests. CORS and rate limits are defensive controls—not authentication.
