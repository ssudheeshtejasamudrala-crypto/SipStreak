import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { randomUUID } from 'node:crypto';

const app = express();
const port = Number(process.env.PORT) || 4000;
const allowedOrigins = (process.env.CORS_ORIGINS || 'http://localhost:5173,http://127.0.0.1:5173').split(',').map(v => v.trim()).filter(Boolean);
const teams = [
  { id: 1, name: 'Hydration Homies', members: 4, score: 81 },
  { id: 2, name: 'Aqua Knights', members: 4, score: 76 },
  { id: 3, name: 'Hostel Block A', members: 4, score: 73 },
  { id: 4, name: 'Hostel Block B', members: 4, score: 72 }
];
const logs = [];

app.disable('x-powered-by');
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({ origin(origin, callback) {
  if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
  return callback(new Error('Origin not allowed by CORS policy'));
}, methods: ['GET', 'POST'], allowedHeaders: ['Content-Type'], maxAge: 600 }));
app.use(express.json({ limit: '10kb', strict: true }));
app.use(rateLimit({ windowMs: 60_000, limit: 90, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: 'Too many requests. Please wait and try again.' } }));
app.use((req, res, next) => { res.setHeader('Cache-Control', 'no-store'); next(); });

app.get('/api/health', (req, res) => res.json({ status: 'ok', app: 'SipStreak HydroHero Hunt', uptimeSeconds: Math.floor(process.uptime()) }));
app.get('/api/teams', (req, res) => res.json([...teams].sort((a, b) => b.score - a.score)));
app.post('/api/logs', (req, res) => {
  const { user, team, ml } = req.body ?? {};
  if (typeof user !== 'string' || user.trim().length < 1 || user.trim().length > 40 ||
      typeof team !== 'string' || !teams.some(t => t.name === team) ||
      !Number.isInteger(ml) || ml < 1 || ml > 3000) {
    return res.status(400).json({ error: 'Invalid log. Name (1–40 chars), known team, and amount (1–3000 ml) are required.' });
  }
  if (logs.length >= 5000) logs.splice(0, 1000);
  const record = { id: randomUUID(), user: user.trim(), team, ml, timestamp: new Date().toISOString() };
  logs.push(record);
  return res.status(201).json(record);
});
app.get('/api/logs', (req, res) => {
  const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 100));
  res.json(logs.slice(-limit).reverse());
});
app.get('/api/leaderboard', (req, res) => res.json([...teams].sort((a, b) => b.score - a.score).map((t, i) => ({ ...t, rank: i + 1 })));
app.use((req, res) => res.status(404).json({ error: 'Route not found' }));
app.use((err, req, res, next) => {
  if (res.headersSent) return next(err);
  if (err.message?.includes('CORS')) return res.status(403).json({ error: 'Origin not allowed' });
  if (err instanceof SyntaxError && err.status === 400) return res.status(400).json({ error: 'Malformed JSON request' });
  console.error('API error:', err.message);
  return res.status(500).json({ error: 'Internal server error' });
});
app.listen(port, () => console.log(`SipStreak API listening on port ${port}`));
